#include <iostream>
#include <Array.h>
#include <LinkedList.h>
#include <TimeSupport.h>
#include <RandomSupport.h>
using namespace std;

int main()
{
	LinkedList myList;
	for(int i = 0; i<6;i++)
	{
		myList.prepend(i);
	}
	myList.print();
	//LinkedList and Array will be performing the same thing
	// int size = 10000;
	// randomizer device = new_randomizer();
	// uniform_distribution dist = new_distribution(0, size);
	// long r = sample(dist, device);
	// LinkedList linkedList;
	// ResizableArray array;
	// for (long i = 0; i < size; i++){
	// 	linkedList.append(i);
	// }
	// for (long i = 0; i < size; i++){
	// 	array.append(i);
	// }
	// timestamp start1 = current_time();
	// for (long i = 0; i < size; i++){
	// 	array.insert(0,r);
	// }
	// timestamp end1 = current_time();
	// long duration1 = time_diff(start1,end1);
	// cout <<"Array done in " << duration1 << " ms."<< endl;
	// timestamp start2 = current_time();
	// for (long i = 0; i < size; i++){
	// 	linkedList.insert(0,r);
	// }
	// timestamp end2 = current_time();
	// long duration2 = time_diff(start2,end2);
	// cout <<"LinkedList done in " << duration2 << " ms."<< endl;
	// cout <<"Inserting at the beginning at a high volume, LinkedList reign supreme." <<endl;
	//LinkedList is more stable
}
//Task 1
/*int main(){
	int size = 10000000;
	randomizer device = new_randomizer();
	uniform_distribution dist = new_distribution(0, size);

	long r = sample(dist, device);
	ResizableArray array;
	
	for (long i = 0; i < size; i++){
		array.append(i);
	}

	cout << endl << "The index number is: " << r << endl << endl;
	timestamp start = current_time();
	array.get(r);
	timestamp end = current_time();
    long duration = time_diff(start,end);
	cout <<"Done in " << duration << " ms."<< endl;
	cout << "Array at index:       " << array.get(r) << endl;
    return 0;
}*/
//Task 2
/*int main()
{
	LinkedList linkedList;
	int size = 10000000;
	
	randomizer device = new_randomizer();
	uniform_distribution dist = new_distribution(0, size-1);
	long r = sample(dist, device);
	for (long i = 0; i < size; i++){
		linkedList.append(i);
		
	}
	cout << endl << "The index number is: " << r << endl << endl;
	cout<< linkedList.get(r) <<endl;
	timestamp start = current_time();
	linkedList.get(r);
	timestamp end = current_time();
	
    long duration = time_diff(start,end);
	cout <<"Done in " << duration << " ms."<< endl;
	return 0;
}*/
//Task 3
/*int main()
{
	int size = 50000000;
	randomizer device = new_randomizer();
	uniform_distribution dist = new_distribution(0, 100);
	ResizableArray array;
	long r = sample(dist, device);
	cout << endl << "The random number is: " << r << endl << endl;
	for (long i = 0; i <= size; i++){
		array.append(i);
	}
	timestamp start = current_time();
	array.insert(size, r);
	timestamp end = current_time();
    long duration = time_diff(start,end);
	cout <<"Done in " << duration << " ms."<< endl;
	cout << "Array at index:       " << array.get(size) << endl;
	cout << "Array at index:       " << array.get(size+1) << endl;
}*/
//Task 4
/*int main()
{
	int size = 50000000;
	randomizer device = new_randomizer();
	uniform_distribution dist = new_distribution(0, 100);
	ResizableArray array;
	long r = sample(dist, device);
	cout << endl << "The random number is: " << r << endl << endl;
	for (long i = 0; i <= size; i++){
		array.append(i);
	}
	timestamp start = current_time();
	array.insert(0, r);
	timestamp end = current_time();
	long duration = time_diff(start,end);
	cout <<"Done in " << duration << " ms."<< endl;
	cout << "Array at index:       " << array.get(0) << endl;
	cout << "Array at index:       " << array.get(0+1) << endl;
}*/
//Task 5
/*int main()
{
	LinkedList linkedList;
	int size = 10000000;
	
	randomizer device = new_randomizer();
	uniform_distribution dist = new_distribution(0, 100);
	long r = sample(dist, device);
	for (long i = 0; i <= size; i++){
		linkedList.append(i);
	}
	cout << endl << "The index number is: " << r << endl << endl;
	timestamp start = current_time();
	linkedList.insert(size, r);
	timestamp end = current_time();
    long duration = time_diff(start,end);
	cout <<"Done in " << duration << " ms."<< endl;
	cout << "Array at index:       " << linkedList.get(size) << endl;
	cout << "Array at index:       " << linkedList.get(size+1) << endl;
	return 0;
}*/
//Task 6
/*int main()
{
	LinkedList linkedList;
	int size = 10000000;
	
	randomizer device = new_randomizer();
	uniform_distribution dist = new_distribution(0, 100);
	long r = sample(dist, device);
	for (long i = 0; i <= size; i++){
		linkedList.append(i);
	}
	cout << endl << "The index number is: " << r << endl << endl;
	timestamp start = current_time();
	linkedList.insert(0, r);
	timestamp end = current_time();
    long duration = time_diff(start,end);
	cout <<"Done in " << duration << " ms."<< endl;
	cout << "Array at index:       " << linkedList.get(0) << endl;
	cout << "Array at index:       " << linkedList.get(0+1) << endl;
	return 0;
}*/
