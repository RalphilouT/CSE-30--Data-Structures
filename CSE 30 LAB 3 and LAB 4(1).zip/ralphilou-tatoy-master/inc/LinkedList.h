#pragma once
#include <iostream>
#include <ostream>
struct Node
{
	int data;
	Node*next;
	Node ()
	{
		data=0;
		next = NULL;
	}
	Node (int n)
	{
		data - n;
		next = NULL;
	}
};
struct LinkedList
{
	Node * head;
	LinkedList()
	{
		head = NULL;
	}
	void append(int value)
	{
		if(head == NULL)
		{
			head = new Node(value);
		}
		else
		{
			Node * newNode = new Node(value);
			Node* temp = head;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			temp ->next = newNode;
		}
	}
	void insert(int index, int value)
	{
		
	}
	int get(int index)
	{
		Node * temp = head;
		for(int i=0; i < index;i++)
		{
			temp = temp->next;
		}
		return temp->data;
	}
	void set(int index, int value)
	{
		Node* temp = head;
		for(int i=0; i < index;i++)
		{
			temp = temp->next;
		}
		temp->data = value;
	}
	void print()
	{
		Node *temp = head;
		while(temp != NULL)
		{
			std::cout << temp->data << std::endl;
		}
	}
	~LinkedList()
	{
		Node* temp = head;
		while(temp != NULL)
		{
			temp = temp->next;
			delete head;
			head = temp;
		}
	}
};