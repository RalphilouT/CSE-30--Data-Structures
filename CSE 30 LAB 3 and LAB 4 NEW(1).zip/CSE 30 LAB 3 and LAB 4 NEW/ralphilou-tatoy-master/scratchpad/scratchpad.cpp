#include <iostream>
#include <Arrays.h>

using namespace std;

int main(int argc, char* argv[]){

	ResizableArray arr;

	

	return 0;

}
