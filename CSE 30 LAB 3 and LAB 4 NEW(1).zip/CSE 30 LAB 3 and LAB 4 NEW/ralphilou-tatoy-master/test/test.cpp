#include <igloo/igloo.h>
#include <Arrays.h>
#include <LinkedList.h>
using namespace igloo;

Context(DefaultConstructorTest){
	Spec(InitialSizeAndCounterTest){
		ResizableArray arr;

		Assert::That(arr.size, Equals(1));
		Assert::That(arr.counter, Equals(0));
	}
};

Context(CopyConstructorTest){
	Spec(EmptyArraysMatch){
		ResizableArray one;
		ResizableArray two;

		Assert::That(one == two, IsTrue());
	}
};

Context(AppendFunctionTest){
	Spec(AppendFiveToEmpty){
		// Hardcode expected value
		ResizableArray expected;
		expected.size = 2;
		expected.counter = 1;
		delete[] expected.data;
		expected.data = new int[2];
		expected.data[0] = 5;

		// Use append function to produce actual value
		ResizableArray actual;
		actual.append(5);

		// Actual should be the same as expected
		Assert::That(actual, Equals(expected));
	}

	Spec(AppendFiveAndSevenToEmpty){
		// Hardcode expected value
		ResizableArray expected;
		expected.size = 4;
		expected.counter = 2;
		delete[] expected.data;
		expected.data = new int[4];
		expected.data[0] = 5;
		expected.data[1] = 7;

		// Use append function to produce actual value
		ResizableArray actual;
		actual.append(5);
		actual.append(7);

		// Actual should be the same as expected
		Assert::That(actual, Equals(expected));
	}

	Spec(AppendFiveSevenAndOneToEmpty){
		// Hardcode expected value
		ResizableArray expected;
		expected.size = 4;
		expected.counter = 3;
		delete[] expected.data;
		expected.data = new int[4];
		expected.data[0] = 5;
		expected.data[1] = 7;
		expected.data[2] = 1;

		// Use append function to produce actual value
		ResizableArray actual;
		actual.append(5);
		actual.append(7);
		actual.append(1);

		// Actual should be the same as expected
		Assert::That(actual, Equals(expected));
	}
	Spec(AppendFiveSevenOneAndSixToEmpty){
		// Hardcode expected value
		ResizableArray expected;
		expected.size = 8;
		expected.counter = 4;
		delete[] expected.data;
		expected.data = new int[8];
		expected.data[0] = 5;
		expected.data[1] = 7;
		expected.data[2] = 1;
		expected.data[3] = 6;

		// Use append function to produce actual value
		ResizableArray actual;
		actual.append(5);
		actual.append(7);
		actual.append(1);
		actual.append(6);

		// Actual should be the same as expected
		Assert::That(actual, Equals(expected));
	}
};
Context(GetFunctionTest){
	Spec(GetPosFive){
		const int index = 10;
		ResizableArray actual;
		for(int i = 0; i < index; i++)
		{
			actual.append(i);
		}
		int test = actual.get(5);
		Assert::That(test, Equals(5));
	}
	Spec(GetPosZero){
		const int index = 10;
		ResizableArray actual;
		for(int i = 0; i < index; i++)
		{
			actual.append(i);
		}
		int test = actual.get(0);
		Assert::That(test, Equals(0));
	}
	Spec(GetPosEnd){
		int index = 10;
		ResizableArray actual;
		for(int i = 0; i < index; i++)
		{
			actual.append(i);
		}
		int test = actual.get(9);
		Assert::That(test, Equals(9));

	}
	Spec(GetPosBeyond){
		int index = 10;
		ResizableArray actual;
		for(int i = 0; i < index; i++)
		{
			actual.append(i);
		}
		int test = actual.get(14);
		Assert::That(test, Equals(0));
	}

};
Context(SetFunctionTest){
	Spec(SetPosZero){
		int index = 10;
		ResizableArray actual;
		for(int i = 0; i < index; i++)
		{
			actual.append(i);
		}
		actual.set(0, 12);
		int test = actual.get(0);
		Assert::That(test, Equals(12));
	}
	Spec(SetPosMid){
		int index = 10;
		ResizableArray actual;
		for(int i = 0; i < index; i++)
		{
			actual.append(i);
		}
		actual.set(5, 12);
		int test = actual.get(5);
		Assert::That(test, Equals(12));
	}
	Spec(SetPosLast){
		int index = 10;
		ResizableArray actual;
		for(int i = 0; i < index; i++)
		{
			actual.append(i);
		}
		actual.set(9, 12);
		int test = actual.get(9);
		Assert::That(test, Equals(12));
	}
};

Context(InsertFunctionTest){
	Spec(InsertFiveIntoEmptyAtPositionZero){
		ResizableArray expected;
		expected.append(5);

		ResizableArray actual;
		actual.insert(0, 5);

		Assert::That(actual, Equals(expected));
	}
	Spec(InsertOneeIntoEmptyAtPositionZero){
		ResizableArray expected;
		expected.append(1);

		ResizableArray actual;
		actual.insert(0, 1);

		Assert::That(actual, Equals(expected));
	}
	Spec(InsertsixIntoEmptyAtPositionZero){
		ResizableArray expected;
		expected.append(1);
		expected.append(2);
		expected.append(3);
		expected.append(4);
		expected.append(5);
		expected.append(6);
		

		ResizableArray actual;
		actual.insert(0, 1);
		actual.insert(1, 2);
		actual.insert(2, 3);
		actual.insert(3, 4);
		actual.insert(4, 5);
		actual.insert(5, 6);

		Assert::That(actual, Equals(expected));
	}
	Spec(InsertsixIntoNotEmptyAtPositionZero){
		ResizableArray expected;
		expected.append(6);
		expected.append(1);
		expected.append(2);
		expected.append(3);
		expected.append(4);
		expected.append(5);
		expected.append(6);
		

		ResizableArray actual;
		actual.append(1);
		actual.append(2);
		actual.append(3);
		actual.append(4);
		actual.append(5);
		actual.append(6);
		actual.insert(0, 6);

		Assert::That(actual, Equals(expected));
	}
	Spec(InsertsixIntoNotEmptyAtPositionMiddle){
		ResizableArray expected;
		expected.append(1);
		expected.append(2);
		expected.append(6);
		expected.append(3);
		expected.append(4);
		expected.append(5);
		expected.append(6);
		

		ResizableArray actual;
		actual.append(1);
		actual.append(2);
		actual.append(3);
		actual.append(4);
		actual.append(5);
		actual.append(6);
		actual.insert(2, 6);

		Assert::That(actual, Equals(expected));
	}
	Spec(InsertsixIntoNotEmptyAtPositionEnd){
		ResizableArray expected;
		expected.append(1);
		expected.append(2);
		expected.append(3);
		expected.append(4);
		expected.append(5);
		expected.append(6);
		expected.append(6);
		

		ResizableArray actual;
		actual.append(1);
		actual.append(2);
		actual.append(3);
		actual.append(4);
		actual.append(5);
		actual.append(6);
		actual.insert(5, 6);

		Assert::That(actual, Equals(expected));
	}
	Spec(InsertsixIntoNotEmptyAtPositionBeyond){
		ResizableArray expected;
		expected.append(1);
		expected.append(2);
		expected.append(3);
		expected.append(4);
		expected.append(5);
		expected.append(6);
		expected.append(0);
		expected.append(0);
		expected.append(6);
		

		ResizableArray actual;
		actual.append(1);
		actual.append(2);
		actual.append(3);
		actual.append(4);
		actual.append(5);
		actual.append(6);
		actual.insert(8, 6);

		Assert::That(actual, Equals(expected));
	}
};


Context(InsertFunctionTestLinkedList){
	Spec(InsertseventysevenIntoEmptyAtPositionZero){
		const int index = 1;
		int test= true;
		LinkedList expected;
		expected.append(77);
		LinkedList actual;
		actual.insert(0,77);
		for(int i = 0; i < index; i++)
		{
			if(actual.get(i) != expected.get(i))
			{
				test = false;
			}
		}

		Assert::That(test, Equals(true));
	}
	Spec(InsertseventysevenIntoHNonEmptyAtPositionZero){
		const int index = 10;
		int test= true;
		LinkedList expected;
		expected.append(77);
		for(int i = 0; i < index; i++)
		{
			expected.append(i);
		}
		LinkedList actual;
		for(int i = 0; i < index; i++)
		{
			actual.append(i);
		}
		actual.insert(0,77);
		for(int i = 0; i < index; i++)
		{
			if(actual.get(i) != expected.get(i))
			{
				test = false;
			}
		}
        // actual.print();
		// std::cout << "cut" << std::endl;
		// expected.print();
		// std::cout << test << std::endl;
		Assert::That(test, Equals(true));
	}
	Spec(InsertseventysevenIntoHNonEmptyAtPositionMiddle)
	{
		const int index = 10;
		int test= true;
		LinkedList expected;
		LinkedList actual;
		for(int i = 0; i < 5; i++)
		{
			expected.append(i);
		}
		expected.append(77);
		expected.append(5);
		expected.append(6);
		expected.append(7);
		expected.append(8);
		expected.append(9);
		for(int i = 0; i < index; i++)
		{
			actual.append(i);
		}
		actual.insert(5,77);
		for(int i = 0; i < index; i++)
		{
			if(actual.get(i) != expected.get(i))
			{
				test = false;
			}
		}
		Assert::That(test, Equals(true));
	}
	Spec(InsertseventysevenIntoHNonEmptyAtPositionEnd)
	{
		const int index = 10;
		int test= true;
		LinkedList expected;
		LinkedList actual;
		for(int i = 0; i < index-1; i++)
		{
			expected.append(i);
		}
		expected.append(77);
		expected.append(9);
		for(int i = 0; i < index; i++)
		{
			actual.append(i);
		}
		actual.insert(9,77);
		for(int i = 0; i < index; i++)
		{
			if(actual.get(i) != expected.get(i))
			{
				test = false;
			}
		}
		// actual.print();
		// std::cout << "cut" << std::endl;
		// expected.print();
		Assert::That(test, Equals(true));
	}
	Spec(InsertseventysevenIntoHNonEmptyAtPositionBeyondSize)
	{
		const int index = 10;
		int test= true;
		LinkedList expected;
		LinkedList actual;
		for(int i = 0; i < index; i++)
		{
			expected.append(i);
		}
		expected.append(0);
		expected.append(0);
		expected.append(77);
		for(int i = 0; i < index; i++)
		{
			actual.append(i);
		}
		actual.insert(12,77);
		for(int i = 0; i < index; i++)
		{
			if(actual.get(i) != expected.get(i))
			{
				test = false;
			}
		}
		// actual.print();
		// std::cout << "cut" << std::endl;
		// expected.print();
		Assert::That(test, Equals(true));
	}

};
Context(GetFunctionTestLinkedList){
	Spec(GetPosZero)
	{
		const int index = 10;
		int test= true;
		LinkedList expected;
		for(int i = 0; i < index; i++)
		{
			expected.append(i);
		}
		test = expected.get(0);
		Assert::That(test, Equals(0));
	}
	Spec(GetPosMid)
	{
		const int index = 10;
		int test= true;
		LinkedList expected;
		for(int i = 0; i < index; i++)
		{
			expected.append(i);
		}
		test = expected.get(5);
		Assert::That(test, Equals(5));
	}
	Spec(GetPosLast)
	{
		const int index = 10;
		int test= true;
		LinkedList expected;
		for(int i = 0; i < index; i++)
		{
			expected.append(i);
		}
		test = expected.get(9);
		Assert::That(test, Equals(9));
	}
};
Context(SetFunctionTestLinkedList){
	Spec(SetFivePosZero)
	{
		const int index = 10;
		int test= true;
		LinkedList expected;
		for(int i = 0; i < index; i++)
		{
			expected.append(i);
		}
		expected.set(0,5);
		test = expected.get(0);
		Assert::That(test, Equals(5));
	}
	Spec(SetFivePosMid)
	{
		const int index = 10;
		int test= true;
		LinkedList expected;
		for(int i = 0; i < index; i++)
		{
			expected.append(i);
		}
		expected.set(5,5);
		test = expected.get(5);
		Assert::That(test, Equals(5));
	}
	Spec(SetFivePosLast)
	{
		const int index = 10;
		int test= true;
		LinkedList expected;
		for(int i = 0; i < index; i++)
		{
			expected.append(i);
		}
		expected.set(9,5);
		test = expected.get(9);
		Assert::That(test, Equals(5));
	}
	
};
int main() {
	// Run all the tests defined above
	return TestRunner::RunAllTests();
}
