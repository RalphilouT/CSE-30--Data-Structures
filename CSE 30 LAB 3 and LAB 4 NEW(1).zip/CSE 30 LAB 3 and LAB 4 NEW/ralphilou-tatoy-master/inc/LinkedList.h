//Ralphilou Tatoy
#pragma once
#include <iostream>
#include <ostream>
struct Node
{
	int data;
	Node*next;
	Node ()
	{
		data=0;
		next = NULL;
	}
	Node (int n)
	{
		data = n;
		next = NULL;
	}
};
struct LinkedList
{
	Node * head;
	LinkedList()
	{
		head = NULL;
	}
	void append(int value)
	{
		if(head == NULL)
		{
			head = new Node(value);
		}
		else
		{
			Node * newNode = new Node(value);
			Node* temp = head;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			temp -> next = newNode;
		}

	}
	void insert(int index, int value)
	{
		if(head == NULL)
		{
			head = new Node(value);
		}
		else
		{
			Node * temp = head;
			int tempCount = 0;
			while(temp->next != NULL)
			{
				temp = temp->next;
				tempCount++;
			}
			if(index > tempCount)
			{
				
				for(int i = tempCount; i < index - 1;i++)
				{
					append(0);
				}
			}
			Node * temp1 = head;
			Node * newNode = new Node(value);
			if (index == 0)
			{
				Node * firstNode = head;
				newNode->next = firstNode;
				head = newNode;
				std::cout << "hello" <<std::endl;
			}
			else
			{
				for(int  i = 0; i < index-1;i++)
				{
					temp1 = temp1->next;
				}
				Node * oldNode = temp1->next;
				temp1->next = newNode;
				newNode->next = oldNode;
			}
			
		}
		
		
		
	}
	int get(int index)
	{
		
		Node * temp = head;
		for(int i=0; i < index;i++)
		{
			temp = temp->next;
		}
		return temp->data;
	}
	void set(int index, int value)
	{
		Node* temp = head;
		for(int i=0; i < index;i++)
		{
			temp = temp->next;
		}
		temp->data = value;
	}
	void print()
	{
		Node *temp = head;
		while(temp != NULL)
		{
			std::cout << temp->data << std::endl;
			temp = temp->next;
		}
		

	}
	~LinkedList()
	{
		Node* temp = head;
		while(temp != NULL)
		{
			temp = temp->next;
			delete head;
			head = temp;
		}
	}
};