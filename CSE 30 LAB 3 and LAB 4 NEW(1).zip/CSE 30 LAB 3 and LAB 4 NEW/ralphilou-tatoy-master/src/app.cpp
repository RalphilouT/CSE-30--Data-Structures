#include <iostream>
#include <Arrays.h>
#include <LinkedList.h>
using namespace std;

int main(){
    ResizableArray array;
    
    for (int i = 0; i < 10; i++) {
        array.append(i);
    }
    
    array.insert(2, 77);
    
    array.insert(10, 89);
    array.insert(20, 100);
    // array.append(101);
    
    // Print out the array
    array.print();

    cout << "count: " << array.counter << endl;
    cout << "size : " << array.size << endl;
    // LinkedList myList;
    // myList.insert(0,33);
	// for(int i = 0; i<6;i++)
	// {
	// 	myList.append(i);
	// }
	// myList.insert(2,77);
	// myList.insert(10,89);
	// myList.append(101);
	// myList.set(6,90);
    // myList.insert(0,5);
	// cout <<myList.get(0) <<endl <<endl;
	// myList.print();
    return 0;
}
