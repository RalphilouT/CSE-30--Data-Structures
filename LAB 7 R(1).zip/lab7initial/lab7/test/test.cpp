#include <igloo/igloo.h>

using namespace igloo;

int main() {
	// Run all the tests defined above
	return TestRunner::RunAllTests();
}
