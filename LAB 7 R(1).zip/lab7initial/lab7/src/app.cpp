#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>
#include <Array.h>
#include <LinkedList.h>
#include <TimeSupport.h>
#include <RandomSupport.h>
#include <BST.h>
//change "mod" to modify hash size and mod.
//Higher the better finding palindrome time but need to consider memory.
const int mod = 15;
using namespace std;
int f(string arr, int x)
{ 
    if(arr.size() < x )
    {
        return 0;
    }
    return int(arr[x])% mod;
}
string reverse(string word){
    reverse(word.begin(), word.end());
    return word;
}

bool find(string word, ResizableArray& arr){
    for (long i = 0; i < arr.count; i++){
        if (word == arr[i]){
            return true;
        }
    }
    return false;
}

int main(){
    string fileNAME = "words.txt";
    fstream file;
    
    const int s = mod;
    ResizableArray words;
    LinkedList table[s][s][s][s];
    file.open(fileNAME,ios::in);
    if (file.is_open()){
        string tp;
        while(getline(file, tp)){
            // while(tp.size()<4)
            // {
            //     tp += 'X';
            // }
            // cout << tp << tp.size() << endl;
            int x = f(tp,0);
            int y = f(tp,1);
            int z = f(tp,2);
            int w = f(tp,3);
            table[x][y][z][w].append(tp);
        }
        file.close(); 
    }
    else{
        cout << "Could not read file..." << endl;
    }
    file.open(fileNAME,ios::in);
    if (file.is_open()){
        string tp;
        while(getline(file, tp)){
            words.append(tp);  
        }
        file.close(); 
    }
    else{
        cout << "Could not read file..." << endl;
    }
    int count = 0;
    timestamp start1 = current_time();
    for (long i = 0; i < words.count; i++){
        string rev = reverse(words[i]);
        int x = f(rev,0);
        int y = f(rev,1);
        int z = f(rev,2);
        int w = f(rev,3);
        
        int found = table[x][y][z][w].search(rev);
        

        if(found == 1)
        {
            count++;
        }
    }
    timestamp end1 = current_time();
    long duration1 = time_diff(start1,end1);
    
    cout <<"Done in " << duration1 << " ms."<< endl;
    cout << "There were " << count << " words that match..." << endl;
//-------------------------------------------------------------------------------------------------------------------------
    // int count = 0;
    // file.open(fileNAME,ios::in);
    // if (file.is_open()){
        
    //     string wordARR;
    //     timestamp start1 = current_time();
    //     while(getline(file, wordARR)){
    //         // while(wordARR.size() <4)
    //         // {
    //         //     reverse(wordARR) += 'X';
                
    //         // }
    //         // cout << wordARR << wordARR.size() << endl;
    //         int x = f(reverse(wordARR),0);
    //         int y = f(reverse(wordARR),1);
    //         int z = f(reverse(wordARR),2);
    //         int w = f(reverse(wordARR),3);
            
    //         int found = table[x][y][z][w].search(reverse(wordARR));
         
            
    //         if(found == 1)
    //         {
    //             count++;
    //         }
    //     }
    //     timestamp end1 = current_time();
    //     long duration1 = time_diff(start1,end1);
    //     cout <<"Done in " << duration1 << " ms."<< endl;

    //     file.close(); 
    // }
    // else{
    //     cout << "Could not read file..." << endl;
    // }
    



    return 0;
}




















